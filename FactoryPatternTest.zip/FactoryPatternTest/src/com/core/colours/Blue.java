package com.core.colours;

public class Blue extends Colour {

	/* Class Methods */

}
