package com.core.colours;

class Red extends Colour {

	/* Class Methods */

}
