package com.core.colours;

class Green extends Colour {

	/* Class Methods */

}
