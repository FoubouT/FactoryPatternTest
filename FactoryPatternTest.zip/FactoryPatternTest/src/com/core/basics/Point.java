package com.core.basics;

public interface Point {

	double getAbscissa();

	void setAbscissa( double abscissa );

	double getOrdinate();

	void setOrdinate( double ordinate );
}
